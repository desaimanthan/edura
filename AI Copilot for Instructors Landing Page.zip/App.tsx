import { useState } from "react";
import { Button } from "./components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./components/ui/card";
import { Badge } from "./components/ui/badge";
import { Input } from "./components/ui/input";
import { Label } from "./components/ui/label";
import { Separator } from "./components/ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./components/ui/tabs";
import { Progress } from "./components/ui/progress";
import { ImageWithFallback } from "./components/figma/ImageWithFallback";
import { CheckCircle, Clock, Users, BookOpen, Zap, TrendingUp, ArrowRight, Star, Sparkles, Brain, Target, Rocket, Award, Globe, Play, Mail, Lock, Eye, EyeOff, ArrowLeft, Quote, Search, Filter, ChevronRight, Calendar, BarChart3, Video, FileText, Download, Share2, Bookmark, ThumbsUp, MessageCircle } from "lucide-react";

type ViewType = "landing" | "login" | "signup" | "courses" | "course-detail";

// Mock course data
const featuredCourses = [
  {
    id: 1,
    title: "Introduction to Machine Learning",
    description: "Learn the fundamentals of ML with hands-on projects and real-world applications.",
    fullDescription: "This comprehensive course introduces you to the exciting world of machine learning. You'll learn fundamental concepts, algorithms, and practical applications through hands-on projects using real-world datasets. From linear regression to neural networks, this course covers essential ML techniques that are widely used in industry today.",
    image: "https://images.unsplash.com/photo-1555949963-aa79dcee981c?w=400&h=240&fit=crop",
    difficulty: "Beginner",
    duration: "8 weeks",
    students: 2847,
    rating: 4.9,
    reviews: 456,
    category: "Machine Learning",
    instructor: "Dr. Sarah Chen",
    instructorBio: "Dr. Sarah Chen is a machine learning researcher at Stanford University with over 10 years of experience in AI. She has published 50+ papers and worked at Google AI.",
    instructorImage: "https://images.unsplash.com/photo-1494790108755-2616b612b786?w=200&h=200&fit=crop",
    price: 149,
    lessons: 24,
    projects: 5,
    certificate: true,
    skills: ["Python", "Scikit-learn", "Data Analysis", "Model Training", "Feature Engineering"],
    prerequisites: ["Basic Python knowledge", "High school mathematics"],
    curriculum: [
      { title: "Introduction to ML", lessons: 3, duration: "45 min" },
      { title: "Data Preprocessing", lessons: 4, duration: "60 min" },
      { title: "Supervised Learning", lessons: 6, duration: "90 min" },
      { title: "Unsupervised Learning", lessons: 4, duration: "60 min" },
      { title: "Model Evaluation", lessons: 3, duration: "45 min" },
      { title: "Advanced Topics", lessons: 4, duration: "75 min" }
    ]
  },
  {
    id: 2,
    title: "Data Science Fundamentals",
    description: "Master data analysis, visualization, and statistical modeling techniques.",
    fullDescription: "Dive deep into the world of data science with this comprehensive course covering statistical analysis, data visualization, and predictive modeling. You'll work with real datasets and learn to extract meaningful insights using industry-standard tools and techniques.",
    image: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=400&h=240&fit=crop",
    difficulty: "Intermediate",
    duration: "10 weeks",
    students: 1923,
    rating: 4.8,
    reviews: 312,
    category: "Data Science",
    instructor: "Prof. Michael Rodriguez",
    instructorBio: "Prof. Michael Rodriguez is a data science expert with 15 years of industry experience at Microsoft and Amazon. He specializes in big data analytics and business intelligence.",
    instructorImage: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=200&h=200&fit=crop",
    price: 199,
    lessons: 32,
    projects: 6,
    certificate: true,
    skills: ["Python", "R", "SQL", "Tableau", "Statistical Analysis", "Data Visualization"],
    prerequisites: ["Basic statistics", "Some programming experience"],
    curriculum: [
      { title: "Data Science Fundamentals", lessons: 4, duration: "60 min" },
      { title: "Statistical Analysis", lessons: 6, duration: "90 min" },
      { title: "Data Visualization", lessons: 5, duration: "75 min" },
      { title: "Database Management", lessons: 4, duration: "60 min" },
      { title: "Predictive Modeling", lessons: 7, duration: "105 min" },
      { title: "Business Intelligence", lessons: 6, duration: "90 min" }
    ]
  },
  {
    id: 3,
    title: "AI Ethics and Governance",
    description: "Explore the ethical implications and governance frameworks for AI systems.",
    fullDescription: "As AI becomes more prevalent in society, understanding its ethical implications is crucial. This course explores bias in AI, privacy concerns, algorithmic accountability, and governance frameworks to ensure responsible AI development and deployment.",
    image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&h=240&fit=crop",
    difficulty: "Advanced",
    duration: "6 weeks",
    students: 1456,
    rating: 4.7,
    reviews: 203,
    category: "AI Ethics",
    instructor: "Dr. Lisa Wang",
    instructorBio: "Dr. Lisa Wang is a leading expert in AI ethics and policy, serving as an advisor to the UN on AI governance. She has a PhD in Computer Science and Law from Harvard.",
    instructorImage: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=200&h=200&fit=crop",
    price: 179,
    lessons: 18,
    projects: 3,
    certificate: true,
    skills: ["AI Ethics", "Policy Analysis", "Risk Assessment", "Governance Frameworks"],
    prerequisites: ["Basic understanding of AI", "Interest in ethics and policy"],
    curriculum: [
      { title: "Introduction to AI Ethics", lessons: 3, duration: "45 min" },
      { title: "Bias and Fairness", lessons: 4, duration: "60 min" },
      { title: "Privacy and Security", lessons: 3, duration: "45 min" },
      { title: "Algorithmic Accountability", lessons: 4, duration: "60 min" },
      { title: "Governance Frameworks", lessons: 2, duration: "30 min" },
      { title: "Future of AI Ethics", lessons: 2, duration: "30 min" }
    ]
  }
];

const allCourses = [
  ...featuredCourses,
  {
    id: 4,
    title: "Deep Learning Essentials",
    description: "Dive deep into neural networks, CNNs, RNNs, and transformer architectures.",
    fullDescription: "Master the cutting-edge field of deep learning with this advanced course. You'll build neural networks from scratch, understand convolutional and recurrent architectures, and work with transformer models that power modern AI applications.",
    image: "https://images.unsplash.com/photo-1518186285589-2f7649de83e0?w=400&h=240&fit=crop",
    difficulty: "Advanced",
    duration: "12 weeks",
    students: 3241,
    rating: 4.9,
    reviews: 567,
    category: "Deep Learning",
    instructor: "Dr. James Thompson",
    instructorBio: "Dr. James Thompson is a deep learning researcher at MIT with expertise in computer vision and NLP. He has contributed to major open-source frameworks including TensorFlow.",
    instructorImage: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&h=200&fit=crop",
    price: 299,
    lessons: 40,
    projects: 8,
    certificate: true,
    skills: ["TensorFlow", "PyTorch", "Neural Networks", "CNNs", "RNNs", "Transformers"],
    prerequisites: ["Machine Learning basics", "Python proficiency", "Linear algebra"],
    curriculum: [
      { title: "Neural Network Fundamentals", lessons: 6, duration: "90 min" },
      { title: "Convolutional Neural Networks", lessons: 8, duration: "120 min" },
      { title: "Recurrent Neural Networks", lessons: 6, duration: "90 min" },
      { title: "Transformer Architecture", lessons: 8, duration: "120 min" },
      { title: "Advanced Optimization", lessons: 6, duration: "90 min" },
      { title: "Deployment and Production", lessons: 6, duration: "90 min" }
    ]
  },
  {
    id: 5,
    title: "Natural Language Processing",
    description: "Build applications that understand and generate human language.",
    fullDescription: "Learn to build intelligent systems that can understand, interpret, and generate human language. This course covers everything from text preprocessing to advanced language models and their applications.",
    image: "https://images.unsplash.com/photo-1516321318423-f06f85e504b3?w=400&h=240&fit=crop",
    difficulty: "Intermediate",
    duration: "9 weeks",
    students: 2156,
    rating: 4.8,
    reviews: 389,
    category: "NLP",
    instructor: "Prof. Emily Davis",
    instructorBio: "Prof. Emily Davis is an NLP expert who has worked on language models at OpenAI and Google. She has a PhD in Computational Linguistics from Stanford University.",
    instructorImage: "https://images.unsplash.com/photo-1494790108755-2616b612b786?w=200&h=200&fit=crop",
    price: 249,
    lessons: 28,
    projects: 6,
    certificate: true,
    skills: ["NLTK", "spaCy", "Transformers", "Text Analysis", "Language Models"],
    prerequisites: ["Python programming", "Basic machine learning", "Linguistics knowledge helpful"],
    curriculum: [
      { title: "Text Preprocessing", lessons: 4, duration: "60 min" },
      { title: "Language Models", lessons: 6, duration: "90 min" },
      { title: "Named Entity Recognition", lessons: 4, duration: "60 min" },
      { title: "Sentiment Analysis", lessons: 5, duration: "75 min" },
      { title: "Machine Translation", lessons: 5, duration: "75 min" },
      { title: "Advanced Applications", lessons: 4, duration: "60 min" }
    ]
  },
  {
    id: 6,
    title: "Computer Vision Fundamentals",
    description: "Learn to process, analyze, and understand visual information using AI.",
    fullDescription: "Explore the fascinating field of computer vision where machines learn to see and understand visual content. Build applications for image classification, object detection, and image generation.",
    image: "https://images.unsplash.com/photo-1485827404703-89b55fcc595e?w=400&h=240&fit=crop",
    difficulty: "Intermediate",
    duration: "11 weeks",
    students: 1789,
    rating: 4.7,
    reviews: 298,
    category: "Computer Vision",
    instructor: "Dr. Alex Kumar",
    instructorBio: "Dr. Alex Kumar is a computer vision researcher at Meta AI with expertise in autonomous vehicles and medical imaging. He holds multiple patents in computer vision technologies.",
    instructorImage: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=200&h=200&fit=crop",
    price: 229,
    lessons: 35,
    projects: 7,
    certificate: true,
    skills: ["OpenCV", "TensorFlow", "Image Processing", "Object Detection", "CNN"],
    prerequisites: ["Python programming", "Basic mathematics", "Machine learning fundamentals"],
    curriculum: [
      { title: "Image Processing Basics", lessons: 5, duration: "75 min" },
      { title: "Feature Detection", lessons: 6, duration: "90 min" },
      { title: "Object Classification", lessons: 7, duration: "105 min" },
      { title: "Object Detection", lessons: 6, duration: "90 min" },
      { title: "Semantic Segmentation", lessons: 5, duration: "75 min" },
      { title: "Generative Models", lessons: 6, duration: "90 min" }
    ]
  },
  {
    id: 7,
    title: "Reinforcement Learning",
    description: "Master algorithms that learn through interaction with environments.",
    fullDescription: "Discover how to build intelligent agents that learn optimal behavior through trial and error. This advanced course covers Q-learning, policy gradients, and modern RL algorithms used in robotics and game AI.",
    image: "https://images.unsplash.com/photo-1504639725590-34d0984388bd?w=400&h=240&fit=crop",
    difficulty: "Advanced",
    duration: "10 weeks",
    students: 1234,
    rating: 4.6,
    reviews: 187,
    category: "Machine Learning",
    instructor: "Prof. David Park",
    instructorBio: "Prof. David Park is a reinforcement learning expert who has worked on autonomous systems at Tesla and DeepMind. He specializes in multi-agent systems and robotics.",
    instructorImage: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&h=200&fit=crop",
    price: 279,
    lessons: 30,
    projects: 5,
    certificate: true,
    skills: ["Q-Learning", "Policy Gradients", "Actor-Critic", "Multi-Agent RL"],
    prerequisites: ["Strong Python skills", "Machine learning experience", "Probability and statistics"],
    curriculum: [
      { title: "RL Fundamentals", lessons: 4, duration: "60 min" },
      { title: "Dynamic Programming", lessons: 5, duration: "75 min" },
      { title: "Monte Carlo Methods", lessons: 4, duration: "60 min" },
      { title: "Temporal Difference Learning", lessons: 6, duration: "90 min" },
      { title: "Policy Gradient Methods", lessons: 6, duration: "90 min" },
      { title: "Advanced RL", lessons: 5, duration: "75 min" }
    ]
  },
  {
    id: 8,
    title: "AI for Business Applications",
    description: "Apply AI solutions to solve real-world business problems and drive innovation.",
    fullDescription: "Learn how to identify, design, and implement AI solutions for business challenges. This practical course bridges the gap between AI technology and business value, covering ROI analysis, implementation strategies, and change management.",
    image: "https://images.unsplash.com/photo-1559136555-9303baea8ebd?w=400&h=240&fit=crop",
    difficulty: "Beginner",
    duration: "7 weeks",
    students: 3567,
    rating: 4.8,
    reviews: 445,
    category: "Business AI",
    instructor: "Dr. Rachel Green",
    instructorBio: "Dr. Rachel Green is a business AI consultant who has helped Fortune 500 companies implement AI strategies. She has an MBA from Wharton and a PhD in Computer Science.",
    instructorImage: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=200&h=200&fit=crop",
    price: 179,
    lessons: 21,
    projects: 4,
    certificate: true,
    skills: ["AI Strategy", "Business Analysis", "ROI Calculation", "Project Management"],
    prerequisites: ["Business experience", "Basic understanding of AI", "No technical background required"],
    curriculum: [
      { title: "AI in Business Context", lessons: 3, duration: "45 min" },
      { title: "Identifying AI Opportunities", lessons: 4, duration: "60 min" },
      { title: "Building AI Teams", lessons: 3, duration: "45 min" },
      { title: "Implementation Strategies", lessons: 4, duration: "60 min" },
      { title: "ROI and Measurement", lessons: 3, duration: "45 min" },
      { title: "Change Management", lessons: 4, duration: "60 min" }
    ]
  }
];

export default function App() {
  const [currentView, setCurrentView] = useState<ViewType>("landing");
  const [selectedCourseId, setSelectedCourseId] = useState<number | null>(null);
  const [showPassword, setShowPassword] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("All");
  const [loginData, setLoginData] = useState({ email: "", password: "" });
  const [signupData, setSignupData] = useState({ 
    firstName: "", 
    lastName: "", 
    email: "", 
    password: "",
    confirmPassword: ""
  });

  const handleGoogleSignIn = () => {
    // Mock Google sign-in functionality
    console.log("Google sign-in clicked");
  };

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    console.log("Login submitted", loginData);
  };

  const handleSignup = (e: React.FormEvent) => {
    e.preventDefault();
    console.log("Signup submitted", signupData);
  };

  const handleCourseClick = (courseId: number) => {
    setSelectedCourseId(courseId);
    setCurrentView("course-detail");
  };

  const categories = ["All", "Machine Learning", "Data Science", "Deep Learning", "NLP", "Computer Vision", "AI Ethics", "Business AI"];

  const filteredCourses = allCourses.filter(course => {
    const matchesSearch = course.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         course.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         course.instructor.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = selectedCategory === "All" || course.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const selectedCourse = selectedCourseId ? allCourses.find(course => course.id === selectedCourseId) : null;

  if (currentView === "course-detail" && selectedCourse) {
    return (
      <div className="min-h-screen bg-gray-50">
        {/* Navigation */}
        <nav className="relative z-50 bg-white border-b border-gray-100 sticky top-0">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex justify-between items-center py-4">
              <div 
                className="flex items-center space-x-3 cursor-pointer"
                onClick={() => setCurrentView("landing")}
              >
                <div className="w-8 h-8 bg-gradient-to-r from-emerald-500 to-teal-500 rounded-lg flex items-center justify-center">
                  <Brain className="w-5 h-5 text-white" />
                </div>
                <span className="text-xl font-semibold text-gray-900">ProfessorAI</span>
              </div>
              <div className="hidden md:flex items-center space-x-8">
                <Button 
                  variant="ghost" 
                  onClick={() => setCurrentView("landing")}
                  className="text-gray-600 hover:text-gray-900"
                >
                  Home
                </Button>
                <Button
                  variant="ghost"
                  onClick={() => setCurrentView("courses")}
                  className="text-gray-600 hover:text-gray-900"
                >
                  Courses
                </Button>
                <a href="#" className="text-gray-600 hover:text-gray-900 transition-colors font-medium">Pricing</a>
                <Button 
                  variant="ghost" 
                  size="sm" 
                  className="text-gray-600 hover:text-gray-900"
                  onClick={() => setCurrentView("login")}
                >
                  Sign In
                </Button>
                <Button 
                  size="sm" 
                  className="bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-600 hover:to-teal-600"
                  onClick={() => setCurrentView("signup")}
                >
                  Get Started
                </Button>
              </div>
            </div>
          </div>
        </nav>

        {/* Course Hero Section */}
        <section className="bg-gradient-to-r from-emerald-600 to-teal-600 text-white py-16">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex items-center gap-4 mb-6">
              <Button 
                variant="ghost" 
                onClick={() => setCurrentView("courses")}
                className="text-white/80 hover:text-white hover:bg-white/10 -ml-4"
              >
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to courses
              </Button>
            </div>
            
            <div className="grid lg:grid-cols-3 gap-12 items-start">
              {/* Left Content */}
              <div className="lg:col-span-2">
                <div className="flex items-center gap-4 mb-4">
                  <Badge 
                    className={`${
                      selectedCourse.difficulty === 'Beginner' ? 'bg-green-100 text-green-700' :
                      selectedCourse.difficulty === 'Intermediate' ? 'bg-blue-100 text-blue-700' :
                      'bg-purple-100 text-purple-700'
                    } border-0`}
                  >
                    {selectedCourse.difficulty}
                  </Badge>
                  <Badge className="bg-white/20 text-white border-0">
                    {selectedCourse.category}
                  </Badge>
                </div>
                
                <h1 className="text-4xl lg:text-5xl font-black mb-6 leading-tight">
                  {selectedCourse.title}
                </h1>
                
                <p className="text-xl text-white/90 mb-8 leading-relaxed">
                  {selectedCourse.fullDescription}
                </p>
                
                <div className="flex items-center gap-8 text-white/80 mb-8">
                  <div className="flex items-center gap-2">
                    <Star className="w-5 h-5 fill-yellow-400 text-yellow-400" />
                    <span className="font-semibold">{selectedCourse.rating}</span>
                    <span>({selectedCourse.reviews} reviews)</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Users className="w-5 h-5" />
                    <span>{selectedCourse.students.toLocaleString()} students</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Clock className="w-5 h-5" />
                    <span>{selectedCourse.duration}</span>
                  </div>
                </div>

                <div className="flex items-center gap-4">
                  <ImageWithFallback
                    src={selectedCourse.instructorImage}
                    alt={selectedCourse.instructor}
                    className="w-12 h-12 rounded-full object-cover"
                  />
                  <div>
                    <p className="font-semibold text-white">Instructor: {selectedCourse.instructor}</p>
                    <p className="text-white/70">AI & Machine Learning Expert</p>
                  </div>
                </div>

                {/* Course Actions */}
                <div className="flex gap-3 mt-8">
                  <Button 
                    size="sm" 
                    className="bg-white/20 backdrop-blur-sm border border-white/30 text-white hover:bg-white/30 hover:text-white font-medium"
                  >
                    <Bookmark className="w-4 h-4 mr-2" />
                    Save Course
                  </Button>
                  <Button 
                    size="sm" 
                    className="bg-white/20 backdrop-blur-sm border border-white/30 text-white hover:bg-white/30 hover:text-white font-medium"
                  >
                    <Share2 className="w-4 h-4 mr-2" />
                    Share
                  </Button>
                </div>
              </div>

              {/* Right Sidebar - Course Image */}
              <div className="lg:col-span-1">
                <div className="bg-white/10 backdrop-blur-sm rounded-xl p-6 border border-white/20">
                  <ImageWithFallback
                    src={selectedCourse.image}
                    alt={selectedCourse.title}
                    className="w-full h-48 object-cover rounded-lg mb-6"
                  />
                  
                  <div className="space-y-4 mb-6">
                    <div className="flex justify-between items-center">
                      <span className="text-white/80">Price</span>
                      <span className="text-2xl font-bold text-white">${selectedCourse.price}</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-white/80">Duration</span>
                      <span className="text-white">{selectedCourse.duration}</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-white/80">Lessons</span>
                      <span className="text-white">{selectedCourse.lessons}</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-white/80">Projects</span>
                      <span className="text-white">{selectedCourse.projects}</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-white/80">Certificate</span>
                      <span className="text-white">{selectedCourse.certificate ? 'Yes' : 'No'}</span>
                    </div>
                  </div>
                  
                  <Button 
                    size="lg"
                    className="w-full bg-white text-emerald-600 hover:bg-gray-100 font-semibold"
                    onClick={() => setCurrentView("signup")}
                  >
                    Enroll Now - ${selectedCourse.price}
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Course Content */}
        <section className="py-16">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid lg:grid-cols-3 gap-12">
              {/* Main Content */}
              <div className="lg:col-span-2">
                <Tabs defaultValue="overview" className="space-y-8">
                  <TabsList className="grid w-full grid-cols-4">
                    <TabsTrigger value="overview">Overview</TabsTrigger>
                    <TabsTrigger value="curriculum">Curriculum</TabsTrigger>
                    <TabsTrigger value="instructor">Instructor</TabsTrigger>
                    <TabsTrigger value="reviews">Reviews</TabsTrigger>
                  </TabsList>
                  
                  <TabsContent value="overview" className="space-y-8">
                    <Card>
                      <CardHeader>
                        <CardTitle>What you'll learn</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="grid md:grid-cols-2 gap-4">
                          {selectedCourse.skills.map((skill, index) => (
                            <div key={index} className="flex items-center gap-3">
                              <CheckCircle className="w-5 h-5 text-emerald-500 flex-shrink-0" />
                              <span className="text-gray-700">{skill}</span>
                            </div>
                          ))}
                        </div>
                      </CardContent>
                    </Card>

                    <Card>
                      <CardHeader>
                        <CardTitle>Prerequisites</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-3">
                          {selectedCourse.prerequisites.map((prereq, index) => (
                            <div key={index} className="flex items-center gap-3">
                              <div className="w-2 h-2 bg-emerald-500 rounded-full flex-shrink-0" />
                              <span className="text-gray-700">{prereq}</span>
                            </div>
                          ))}
                        </div>
                      </CardContent>
                    </Card>

                    <Card>
                      <CardHeader>
                        <CardTitle>Course Description</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <p className="text-gray-700 leading-relaxed">
                          {selectedCourse.fullDescription}
                        </p>
                      </CardContent>
                    </Card>
                  </TabsContent>

                  <TabsContent value="curriculum" className="space-y-6">
                    {selectedCourse.curriculum.map((module, index) => (
                      <Card key={index}>
                        <CardHeader>
                          <div className="flex items-center justify-between">
                            <CardTitle className="text-lg">
                              Module {index + 1}: {module.title}
                            </CardTitle>
                            <div className="flex items-center gap-4 text-sm text-gray-500">
                              <span>{module.lessons} lessons</span>
                              <span>{module.duration}</span>
                            </div>
                          </div>
                        </CardHeader>
                        <CardContent>
                          <div className="space-y-3">
                            {Array.from({ length: module.lessons }, (_, i) => (
                              <div key={i} className="flex items-center gap-3 p-3 rounded-lg border border-gray-100">
                                <Video className="w-5 h-5 text-emerald-500" />
                                <span className="flex-1">Lesson {i + 1}: Introduction to concepts</span>
                                <span className="text-sm text-gray-500">
                                  {Math.floor(parseInt(module.duration) / module.lessons)} min
                                </span>
                              </div>
                            ))}
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </TabsContent>

                  <TabsContent value="instructor" className="space-y-6">
                    <Card>
                      <CardContent className="pt-6">
                        <div className="flex items-start gap-6">
                          <ImageWithFallback
                            src={selectedCourse.instructorImage}
                            alt={selectedCourse.instructor}
                            className="w-24 h-24 rounded-full object-cover"
                          />
                          <div className="flex-1">
                            <h3 className="text-2xl font-semibold mb-2">{selectedCourse.instructor}</h3>
                            <p className="text-gray-600 mb-4">AI & Machine Learning Expert</p>
                            <p className="text-gray-700 leading-relaxed">
                              {selectedCourse.instructorBio}
                            </p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>

                    <Card>
                      <CardHeader>
                        <CardTitle>Instructor Stats</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="grid grid-cols-3 gap-6 text-center">
                          <div>
                            <div className="text-2xl font-bold text-emerald-600">4.9</div>
                            <div className="text-sm text-gray-500">Average Rating</div>
                          </div>
                          <div>
                            <div className="text-2xl font-bold text-emerald-600">15K+</div>
                            <div className="text-sm text-gray-500">Students Taught</div>
                          </div>
                          <div>
                            <div className="text-2xl font-bold text-emerald-600">8</div>
                            <div className="text-sm text-gray-500">Courses</div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </TabsContent>

                  <TabsContent value="reviews" className="space-y-6">
                    <Card>
                      <CardHeader>
                        <CardTitle>Student Reviews</CardTitle>
                        <div className="flex items-center gap-4">
                          <div className="flex items-center gap-2">
                            <Star className="w-5 h-5 fill-yellow-400 text-yellow-400" />
                            <span className="text-xl font-semibold">{selectedCourse.rating}</span>
                          </div>
                          <span className="text-gray-500">({selectedCourse.reviews} reviews)</span>
                        </div>
                      </CardHeader>
                      <CardContent className="space-y-6">
                        {/* Sample Reviews */}
                        {[
                          {
                            name: "Sarah Johnson",
                            rating: 5,
                            comment: "Excellent course! The instructor explains complex concepts clearly and the hands-on projects really help solidify the learning.",
                            date: "2 weeks ago"
                          },
                          {
                            name: "Mike Chen",
                            rating: 5,
                            comment: "Best ML course I've taken. Great balance of theory and practical application. Highly recommend!",
                            date: "1 month ago"
                          },
                          {
                            name: "Jessica Brown",
                            rating: 4,
                            comment: "Very comprehensive course. Could use more advanced topics but overall great for beginners to intermediate learners.",
                            date: "1 month ago"
                          }
                        ].map((review, index) => (
                          <div key={index} className="border-b border-gray-100 pb-6 last:border-0">
                            <div className="flex items-start gap-4">
                              <div className="w-10 h-10 bg-emerald-100 rounded-full flex items-center justify-center">
                                <span className="font-semibold text-emerald-600">
                                  {review.name.split(' ').map(n => n[0]).join('')}
                                </span>
                              </div>
                              <div className="flex-1">
                                <div className="flex items-center gap-3 mb-2">
                                  <span className="font-semibold">{review.name}</span>
                                  <div className="flex">
                                    {[...Array(review.rating)].map((_, i) => (
                                      <Star key={i} className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                                    ))}
                                  </div>
                                  <span className="text-sm text-gray-500">{review.date}</span>
                                </div>
                                <p className="text-gray-700">{review.comment}</p>
                                <div className="flex items-center gap-4 mt-3">
                                  <Button variant="ghost" size="sm" className="text-gray-500 hover:text-gray-700">
                                    <ThumbsUp className="w-4 h-4 mr-1" />
                                    Helpful (12)
                                  </Button>
                                  <Button variant="ghost" size="sm" className="text-gray-500 hover:text-gray-700">
                                    <MessageCircle className="w-4 h-4 mr-1" />
                                    Reply
                                  </Button>
                                </div>
                              </div>
                            </div>
                          </div>
                        ))}
                      </CardContent>
                    </Card>
                  </TabsContent>
                </Tabs>
              </div>

              {/* Sidebar */}
              <div className="lg:col-span-1">
                <div className="sticky top-32 space-y-6">
                  <Card>
                    <CardHeader>
                      <CardTitle>Course Features</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="flex items-center gap-3">
                        <Video className="w-5 h-5 text-emerald-500" />
                        <span>{selectedCourse.lessons} video lessons</span>
                      </div>
                      <div className="flex items-center gap-3">
                        <FileText className="w-5 h-5 text-emerald-500" />
                        <span>{selectedCourse.projects} hands-on projects</span>
                      </div>
                      <div className="flex items-center gap-3">
                        <Download className="w-5 h-5 text-emerald-500" />
                        <span>Downloadable resources</span>
                      </div>
                      <div className="flex items-center gap-3">
                        <Award className="w-5 h-5 text-emerald-500" />
                        <span>Certificate of completion</span>
                      </div>
                      <div className="flex items-center gap-3">
                        <Globe className="w-5 h-5 text-emerald-500" />
                        <span>Lifetime access</span>
                      </div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader>
                      <CardTitle>Related Courses</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      {allCourses
                        .filter(course => course.id !== selectedCourse.id && course.category === selectedCourse.category)
                        .slice(0, 2)
                        .map(course => (
                          <div 
                            key={course.id} 
                            className="flex gap-3 p-3 rounded-lg border border-gray-100 hover:border-gray-200 cursor-pointer transition-colors"
                            onClick={() => handleCourseClick(course.id)}
                          >
                            <ImageWithFallback
                              src={course.image}
                              alt={course.title}
                              className="w-16 h-12 object-cover rounded"
                            />
                            <div className="flex-1">
                              <h4 className="font-semibold text-sm line-clamp-2">{course.title}</h4>
                              <div className="flex items-center gap-2 mt-1">
                                <Star className="w-3 h-3 fill-yellow-400 text-yellow-400" />
                                <span className="text-xs text-gray-500">{course.rating}</span>
                              </div>
                            </div>
                          </div>
                        ))}
                    </CardContent>
                  </Card>
                </div>
              </div>
            </div>
          </div>
        </section>
      </div>
    );
  }

  if (currentView === "courses") {
    return (
      <div className="min-h-screen bg-gray-50">
        {/* Navigation */}
        <nav className="relative z-50 bg-white border-b border-gray-100 sticky top-0">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex justify-between items-center py-4">
              <div 
                className="flex items-center space-x-3 cursor-pointer"
                onClick={() => setCurrentView("landing")}
              >
                <div className="w-8 h-8 bg-gradient-to-r from-emerald-500 to-teal-500 rounded-lg flex items-center justify-center">
                  <Brain className="w-5 h-5 text-white" />
                </div>
                <span className="text-xl font-semibold text-gray-900">ProfessorAI</span>
              </div>
              <div className="hidden md:flex items-center space-x-8">
                <Button 
                  variant="ghost" 
                  onClick={() => setCurrentView("landing")}
                  className="text-gray-600 hover:text-gray-900"
                >
                  Home
                </Button>
                <a href="#" className="text-emerald-600 font-medium">Courses</a>
                <a href="#" className="text-gray-600 hover:text-gray-900 transition-colors font-medium">Pricing</a>
                <Button 
                  variant="ghost" 
                  size="sm" 
                  className="text-gray-600 hover:text-gray-900"
                  onClick={() => setCurrentView("login")}
                >
                  Sign In
                </Button>
                <Button 
                  size="sm" 
                  className="bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-600 hover:to-teal-600"
                  onClick={() => setCurrentView("signup")}
                >
                  Get Started
                </Button>
              </div>
            </div>
          </div>
        </nav>

        {/* Course Catalog Header */}
        <section className="bg-gradient-to-r from-emerald-600 to-teal-600 text-white py-16">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <div className="max-w-3xl">
              <h1 className="text-4xl lg:text-5xl font-black mb-6 leading-tight">
                Explore Our AI & Data Science Courses
              </h1>
              <p className="text-xl text-white/90 mb-8 leading-relaxed">
                Master cutting-edge AI technologies with expert-led courses designed for modern learners.
              </p>
              
              {/* Search and Filter */}
              <div className="flex flex-col sm:flex-row gap-4">
                <div className="relative flex-1">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                  <Input
                    placeholder="Search courses, instructors, topics..."
                    className="pl-10 h-12 text-base bg-white text-gray-900 border-0"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                  />
                </div>
                <div className="relative">
                  <select 
                    className="h-12 px-4 pr-10 bg-white text-gray-900 border-0 rounded-md font-medium appearance-none cursor-pointer"
                    value={selectedCategory}
                    onChange={(e) => setSelectedCategory(e.target.value)}
                  >
                    {categories.map(category => (
                      <option key={category} value={category}>{category}</option>
                    ))}
                  </select>
                  <Filter className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5 pointer-events-none" />
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Course Grid */}
        <section className="py-16">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex items-center justify-between mb-8">
              <div>
                <h2 className="text-2xl font-black text-gray-900 mb-2">
                  {filteredCourses.length} Course{filteredCourses.length !== 1 ? 's' : ''} Found
                </h2>
                <p className="text-gray-600">
                  {selectedCategory !== "All" ? `Showing ${selectedCategory} courses` : "All available courses"}
                </p>
              </div>
            </div>

            <div className="grid md:grid-cols-2 xl:grid-cols-3 gap-8">
              {filteredCourses.map((course) => (
                <Card 
                  key={course.id} 
                  className="group overflow-hidden bg-white border border-gray-200 hover:border-gray-300 hover:shadow-xl transition-all duration-300 cursor-pointer"
                  onClick={() => handleCourseClick(course.id)}
                >
                  <div className="relative overflow-hidden">
                    <ImageWithFallback
                      src={course.image}
                      alt={course.title}
                      className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                    <div className="absolute top-4 left-4">
                      <Badge 
                        className={`${
                          course.difficulty === 'Beginner' ? 'bg-green-100 text-green-700' :
                          course.difficulty === 'Intermediate' ? 'bg-blue-100 text-blue-700' :
                          'bg-purple-100 text-purple-700'
                        } border-0`}
                      >
                        {course.difficulty}
                      </Badge>
                    </div>
                    <div className="absolute top-4 right-4">
                      <Badge className="bg-white/90 text-gray-700 border-0">
                        {course.category}
                      </Badge>
                    </div>
                  </div>
                  
                  <CardHeader className="pb-3">
                    <CardTitle className="text-xl font-semibold text-gray-900 mb-2 line-clamp-2">
                      {course.title}
                    </CardTitle>
                    <CardDescription className="text-gray-600 leading-relaxed line-clamp-3">
                      {course.description}
                    </CardDescription>
                  </CardHeader>
                  
                  <CardContent className="space-y-4">
                    <div className="flex items-center text-sm text-gray-500 space-x-4">
                      <div className="flex items-center gap-1">
                        <Calendar className="w-4 h-4" />
                        <span>{course.duration}</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <Users className="w-4 h-4" />
                        <span>{course.students.toLocaleString()}</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                        <span>{course.rating}</span>
                      </div>
                    </div>
                    
                    <div className="flex items-center justify-between pt-2">
                      <div>
                        <p className="text-sm text-gray-500">Instructor</p>
                        <p className="font-semibold text-gray-900">{course.instructor}</p>
                      </div>
                      <Button 
                        className="bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-600 hover:to-teal-600"
                        onClick={(e) => {
                          e.stopPropagation();
                          setCurrentView("signup");
                        }}
                      >
                        Enroll Now
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            {filteredCourses.length === 0 && (
              <div className="text-center py-16">
                <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Search className="w-8 h-8 text-gray-400" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-2">No courses found</h3>
                <p className="text-gray-600 mb-6">Try adjusting your search or filters to find more courses.</p>
                <Button 
                  variant="outline"
                  onClick={() => {
                    setSearchQuery("");
                    setSelectedCategory("All");
                  }}
                >
                  Clear Filters
                </Button>
              </div>
            )}
          </div>
        </section>

        {/* CTA Section */}
        <section className="bg-slate-900 text-white py-16">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <h2 className="text-3xl lg:text-4xl font-black mb-4">
              Ready to Start Learning?
            </h2>
            <p className="text-xl text-white/80 mb-8 max-w-2xl mx-auto">
              Join thousands of students already advancing their AI and data science skills.
            </p>
            <Button 
              size="lg" 
              className="bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-600 hover:to-teal-600 text-lg px-8 py-3 h-auto"
              onClick={() => setCurrentView("signup")}
            >
              Create Free Account
              <ArrowRight className="w-5 h-5 ml-2" />
            </Button>
          </div>
        </section>
      </div>
    );
  }

  if (currentView === "login") {
    return (
      <div className="min-h-screen grid lg:grid-cols-2">
        {/* Left Panel - Branding */}
        <div className="hidden lg:flex bg-gradient-to-br from-emerald-600 via-emerald-700 to-teal-800 text-white flex-col justify-between p-12 relative overflow-hidden">
          {/* Background Pattern */}
          <div className="absolute inset-0 bg-gradient-to-br from-emerald-500/20 to-transparent"></div>
          <div className="absolute top-0 right-0 w-96 h-96 bg-white/5 rounded-full blur-3xl transform translate-x-32 -translate-y-32"></div>
          <div className="absolute bottom-0 left-0 w-96 h-96 bg-white/5 rounded-full blur-3xl transform -translate-x-32 translate-y-32"></div>
          
          <div className="relative z-10">
            {/* Logo */}
            <div className="flex items-center space-x-3 mb-16">
              <div className="w-10 h-10 bg-white/20 backdrop-blur-sm rounded-xl flex items-center justify-center">
                <Brain className="w-6 h-6 text-white" />
              </div>
              <span className="text-2xl font-bold">ProfessorAI</span>
            </div>

            {/* Main Content */}
            <div className="max-w-lg">
              <h1 className="text-4xl font-black mb-6 leading-tight">
                Welcome back to the future of teaching
              </h1>
              <p className="text-xl text-white/90 mb-8 leading-relaxed">
                Continue creating amazing courses with AI that understands pedagogy.
              </p>
              
              {/* Feature Highlights */}
              <div className="space-y-4">
                {[
                  "50% faster course creation",
                  "Always up-to-date content",
                  "Personalized for every student"
                ].map((feature, index) => (
                  <div key={index} className="flex items-center gap-3">
                    <div className="w-6 h-6 bg-white/20 rounded-full flex items-center justify-center">
                      <CheckCircle className="w-4 h-4 text-white" />
                    </div>
                    <span className="text-white/90">{feature}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Bottom Testimonial */}
          <div className="relative z-10">
            <div className="bg-white/10 backdrop-blur-sm rounded-xl p-6 border border-white/20">
              <Quote className="w-8 h-8 text-white/60 mb-4" />
              <p className="text-white/90 mb-4 leading-relaxed">
                "ProfessorAI has completely transformed how I create courses. What used to take weeks now takes days."
              </p>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-gradient-to-r from-teal-400 to-emerald-400 rounded-full flex items-center justify-center">
                  <span className="font-semibold text-emerald-900 text-sm">SM</span>
                </div>
                <div>
                  <p className="font-semibold text-white">Dr. Sarah Mitchell</p>
                  <p className="text-white/60 text-sm">Professor, MIT</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Right Panel - Login Form */}
        <div className="flex items-center justify-center p-8 bg-gray-50">
          <div className="w-full max-w-md">
            {/* Back Button */}
            <Button 
              variant="ghost" 
              onClick={() => setCurrentView("landing")}
              className="mb-8 text-gray-600 hover:text-gray-900 -ml-4"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to home
            </Button>

            {/* Mobile Logo */}
            <div className="lg:hidden flex items-center justify-center space-x-3 mb-8">
              <div className="w-10 h-10 bg-gradient-to-r from-emerald-500 to-teal-500 rounded-lg flex items-center justify-center">
                <Brain className="w-6 h-6 text-white" />
              </div>
              <span className="text-2xl font-semibold text-gray-900">ProfessorAI</span>
            </div>

            <Card className="border-0 shadow-none bg-transparent">
              <CardHeader className="text-center pb-8 px-0">
                <CardTitle className="text-3xl font-black text-gray-900 mb-2">Sign in</CardTitle>
                <CardDescription className="text-gray-600">
                  Enter your credentials to access your account
                </CardDescription>
              </CardHeader>
              
              <CardContent className="space-y-6 px-0">
                {/* Google Sign In */}
                <Button 
                  variant="outline" 
                  className="w-full h-14 border-gray-300 hover:bg-gray-50 text-base"
                  onClick={handleGoogleSignIn}
                >
                  <svg className="w-5 h-5 mr-3" viewBox="0 0 24 24">
                    <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
                    <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
                    <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/>
                    <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/>
                  </svg>
                  Continue with Google
                </Button>

                <div className="relative">
                  <div className="absolute inset-0 flex items-center">
                    <Separator className="w-full" />
                  </div>
                  <div className="relative flex justify-center text-xs uppercase">
                    <span className="bg-gray-50 px-3 text-gray-500">Or</span>
                  </div>
                </div>

                {/* Login Form */}
                <form onSubmit={handleLogin} className="space-y-5">
                  <div className="space-y-2">
                    <Label htmlFor="email" className="text-sm font-medium text-gray-700">Email</Label>
                    <Input
                      id="email"
                      type="email"
                      placeholder="Enter your email"
                      className="h-14 text-base bg-white border-gray-300 focus:border-emerald-500 focus:ring-emerald-500"
                      value={loginData.email}
                      onChange={(e) => setLoginData({...loginData, email: e.target.value})}
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <Label htmlFor="password" className="text-sm font-medium text-gray-700">Password</Label>
                      <Button variant="link" className="text-sm text-emerald-600 hover:text-emerald-700 p-0 h-auto">
                        Forgot password?
                      </Button>
                    </div>
                    <div className="relative">
                      <Input
                        id="password"
                        type={showPassword ? "text" : "password"}
                        placeholder="Enter your password"
                        className="h-14 pr-12 text-base bg-white border-gray-300 focus:border-emerald-500 focus:ring-emerald-500"
                        value={loginData.password}
                        onChange={(e) => setLoginData({...loginData, password: e.target.value})}
                        required
                      />
                      <Button
                        type="button"
                        variant="ghost"
                        size="sm"
                        className="absolute right-2 top-1/2 transform -translate-y-1/2 h-8 w-8 p-0 hover:bg-gray-100"
                        onClick={() => setShowPassword(!showPassword)}
                      >
                        {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                      </Button>
                    </div>
                  </div>

                  <div className="flex items-center space-x-2">
                    <input type="checkbox" id="remember" className="rounded border-gray-300" />
                    <Label htmlFor="remember" className="text-sm text-gray-600">Remember me for 30 days</Label>
                  </div>

                  <Button 
                    type="submit" 
                    className="w-full h-14 bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-600 hover:to-teal-600 text-base font-semibold"
                  >
                    Sign in
                  </Button>
                </form>

                <div className="text-center pt-4">
                  <span className="text-gray-600">Don't have an account? </span>
                  <Button 
                    variant="link" 
                    className="text-emerald-600 hover:text-emerald-700 p-0 font-semibold"
                    onClick={() => setCurrentView("signup")}
                  >
                    Sign up for free
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    );
  }

  if (currentView === "signup") {
    return (
      <div className="min-h-screen grid lg:grid-cols-2">
        {/* Left Panel - Branding */}
        <div className="hidden lg:flex bg-gradient-to-br from-emerald-600 via-emerald-700 to-teal-800 text-white flex-col justify-between p-12 relative overflow-hidden">
          {/* Background Pattern */}
          <div className="absolute inset-0 bg-gradient-to-br from-emerald-500/20 to-transparent"></div>
          <div className="absolute top-0 right-0 w-96 h-96 bg-white/5 rounded-full blur-3xl transform translate-x-32 -translate-y-32"></div>
          <div className="absolute bottom-0 left-0 w-96 h-96 bg-white/5 rounded-full blur-3xl transform -translate-x-32 translate-y-32"></div>
          
          <div className="relative z-10">
            {/* Logo */}
            <div className="flex items-center space-x-3 mb-16">
              <div className="w-10 h-10 bg-white/20 backdrop-blur-sm rounded-xl flex items-center justify-center">
                <Brain className="w-6 h-6 text-white" />
              </div>
              <span className="text-2xl font-bold">ProfessorAI</span>
            </div>

            {/* Main Content */}
            <div className="max-w-lg">
              <h1 className="text-4xl font-black mb-6 leading-tight">
                Join 10,000+ educators transforming education
              </h1>
              <p className="text-xl text-white/90 mb-8 leading-relaxed">
                Start creating personalized, AI-powered courses that adapt to every student's needs.
              </p>
              
              {/* Stats */}
              <div className="grid grid-cols-2 gap-6 mb-8">
                <div className="bg-white/10 backdrop-blur-sm rounded-xl p-4 border border-white/20">
                  <div className="text-2xl font-black text-white">50%</div>
                  <div className="text-white/70 text-sm">Faster Creation</div>
                </div>
                <div className="bg-white/10 backdrop-blur-sm rounded-xl p-4 border border-white/20">
                  <div className="text-2xl font-black text-white">95%</div>
                  <div className="text-white/70 text-sm">Satisfaction</div>
                </div>
              </div>

              {/* Features */}
              <div className="space-y-3">
                {[
                  "AI-powered curriculum generation",
                  "Personalized learning paths",
                  "Real-time content updates",
                  "Smart assessment tools"
                ].map((feature, index) => (
                  <div key={index} className="flex items-center gap-3">
                    <div className="w-5 h-5 bg-white/20 rounded-full flex items-center justify-center">
                      <CheckCircle className="w-3 h-3 text-white" />
                    </div>
                    <span className="text-white/90 text-sm">{feature}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Bottom Badge */}
          <div className="relative z-10">
            <div className="inline-flex items-center gap-2 bg-white/20 backdrop-blur-sm rounded-full px-4 py-2 border border-white/30">
              <Star className="w-4 h-4 text-white" />
              <span className="text-white text-sm font-medium">Trusted by top universities</span>
            </div>
          </div>
        </div>

        {/* Right Panel - Signup Form */}
        <div className="flex items-center justify-center p-8 bg-gray-50">
          <div className="w-full max-w-md">
            {/* Back Button */}
            <Button 
              variant="ghost" 
              onClick={() => setCurrentView("landing")}
              className="mb-8 text-gray-600 hover:text-gray-900 -ml-4"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to home
            </Button>

            {/* Mobile Logo */}
            <div className="lg:hidden flex items-center justify-center space-x-3 mb-8">
              <div className="w-10 h-10 bg-gradient-to-r from-emerald-500 to-teal-500 rounded-lg flex items-center justify-center">
                <Brain className="w-6 h-6 text-white" />
              </div>
              <span className="text-2xl font-semibold text-gray-900">ProfessorAI</span>
            </div>

            <Card className="border-0 shadow-none bg-transparent">
              <CardHeader className="text-center pb-8 px-0">
                <CardTitle className="text-3xl font-black text-gray-900 mb-2">Create your account</CardTitle>
                <CardDescription className="text-gray-600">
                  Start your 14-day free trial. No credit card required.
                </CardDescription>
              </CardHeader>
              
              <CardContent className="space-y-6 px-0">
                {/* Google Sign Up */}
                <Button 
                  variant="outline" 
                  className="w-full h-14 border-gray-300 hover:bg-gray-50 text-base"
                  onClick={handleGoogleSignIn}
                >
                  <svg className="w-5 h-5 mr-3" viewBox="0 0 24 24">
                    <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
                    <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
                    <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/>
                    <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/>
                  </svg>
                  Continue with Google
                </Button>

                <div className="relative">
                  <div className="absolute inset-0 flex items-center">
                    <Separator className="w-full" />
                  </div>
                  <div className="relative flex justify-center text-xs uppercase">
                    <span className="bg-gray-50 px-3 text-gray-500">Or</span>
                  </div>
                </div>

                {/* Signup Form */}
                <form onSubmit={handleSignup} className="space-y-5">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="firstName" className="text-sm font-medium text-gray-700">First name</Label>
                      <Input
                        id="firstName"
                        placeholder="John"
                        className="h-12 text-base bg-white border-gray-300 focus:border-emerald-500 focus:ring-emerald-500"
                        value={signupData.firstName}
                        onChange={(e) => setSignupData({...signupData, firstName: e.target.value})}
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="lastName" className="text-sm font-medium text-gray-700">Last name</Label>
                      <Input
                        id="lastName"
                        placeholder="Doe"
                        className="h-12 text-base bg-white border-gray-300 focus:border-emerald-500 focus:ring-emerald-500"
                        value={signupData.lastName}
                        onChange={(e) => setSignupData({...signupData, lastName: e.target.value})}
                        required
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="email" className="text-sm font-medium text-gray-700">Work email</Label>
                    <Input
                      id="email"
                      type="email"
                      placeholder="john@university.edu"
                      className="h-12 text-base bg-white border-gray-300 focus:border-emerald-500 focus:ring-emerald-500"
                      value={signupData.email}
                      onChange={(e) => setSignupData({...signupData, email: e.target.value})}
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="password" className="text-sm font-medium text-gray-700">Password</Label>
                    <div className="relative">
                      <Input
                        id="password"
                        type={showPassword ? "text" : "password"}
                        placeholder="Create a strong password"
                        className="h-12 pr-12 text-base bg-white border-gray-300 focus:border-emerald-500 focus:ring-emerald-500"
                        value={signupData.password}
                        onChange={(e) => setSignupData({...signupData, password: e.target.value})}
                        required
                      />
                      <Button
                        type="button"
                        variant="ghost"
                        size="sm"
                        className="absolute right-2 top-1/2 transform -translate-y-1/2 h-8 w-8 p-0 hover:bg-gray-100"
                        onClick={() => setShowPassword(!showPassword)}
                      >
                        {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                      </Button>
                    </div>
                    <p className="text-xs text-gray-500">Must be at least 8 characters</p>
                  </div>

                  <div className="flex items-start space-x-2 pt-2">
                    <input type="checkbox" id="terms" className="mt-1 rounded border-gray-300" required />
                    <Label htmlFor="terms" className="text-xs text-gray-600 leading-relaxed">
                      I agree to the <a href="#" className="text-emerald-600 hover:text-emerald-700 underline">Terms of Service</a> and <a href="#" className="text-emerald-600 hover:text-emerald-700 underline">Privacy Policy</a>
                    </Label>
                  </div>

                  <Button 
                    type="submit" 
                    className="w-full h-14 bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-600 hover:to-teal-600 text-base font-semibold"
                  >
                    Create account
                  </Button>
                </form>

                <div className="text-center pt-4">
                  <span className="text-gray-600">Already have an account? </span>
                  <Button 
                    variant="link" 
                    className="text-emerald-600 hover:text-emerald-700 p-0 font-semibold"
                    onClick={() => setCurrentView("login")}
                  >
                    Sign in
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    );
  }

  // Landing Page (default view)
  return (
    <div className="min-h-screen overflow-x-hidden">
      {/* Navigation */}
      <nav className="relative z-50 bg-white border-b border-gray-100">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-gradient-to-r from-emerald-500 to-teal-500 rounded-lg flex items-center justify-center">
                <Brain className="w-5 h-5 text-white" />
              </div>
              <span className="text-xl font-semibold text-gray-900">ProfessorAI</span>
            </div>
            <div className="hidden md:flex items-center space-x-8">
              <a href="#features" className="text-gray-600 hover:text-gray-900 transition-colors font-medium">Features</a>
              <Button
                variant="ghost"
                onClick={() => setCurrentView("courses")}
                className="text-gray-600 hover:text-gray-900 transition-colors font-medium"
              >
                Courses
              </Button>
              <a href="#pricing" className="text-gray-600 hover:text-gray-900 transition-colors font-medium">Pricing</a>
              <Button 
                variant="ghost" 
                size="sm" 
                className="text-gray-600 hover:text-gray-900"
                onClick={() => setCurrentView("login")}
              >
                Sign In
              </Button>
              <Button 
                size="sm" 
                className="bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-600 hover:to-teal-600"
                onClick={() => setCurrentView("signup")}
              >
                Get Started
              </Button>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="bg-white py-16 lg:py-24">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            {/* Left Content */}
            <div className="lg:pr-8">
              <div className="inline-flex items-center gap-2 bg-emerald-50 border border-emerald-200 rounded-full px-4 py-2 mb-6">
                <div className="w-2 h-2 bg-emerald-500 rounded-full"></div>
                <span className="text-emerald-700 font-medium text-sm">Reduce Course Creation Time by 50%</span>
              </div>
              
              <h1 className="text-4xl lg:text-5xl xl:text-6xl font-black mb-6 leading-tight text-gray-900">
                AI Copilot for
                <br />
                <span className="bg-gradient-to-r from-emerald-600 to-teal-600 bg-clip-text text-transparent">
                  Modern Instructors
                </span>
              </h1>
              
              <p className="text-lg lg:text-xl text-gray-600 mb-8 leading-relaxed">
                Scale your expertise with AI that creates personalized curricula, keeps content fresh, and adapts to every student's learning style.
              </p>
              
              <div className="flex flex-col sm:flex-row gap-4 mb-8">
                <Button 
                  size="lg" 
                  className="bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-600 hover:to-teal-600 text-lg px-8 py-3 h-auto"
                  onClick={() => setCurrentView("signup")}
                >
                  Start Free Trial
                  <ArrowRight className="w-5 h-5 ml-2" />
                </Button>
                <Button variant="outline" size="lg" className="text-lg px-8 py-3 h-auto border-gray-300 text-gray-700 hover:bg-gray-50">
                  <Play className="w-5 h-5 mr-2" />
                  Watch Demo
                </Button>
              </div>
              
              <div className="flex items-center gap-6 text-sm text-gray-500">
                <div className="flex items-center gap-2">
                  <CheckCircle className="w-4 h-4 text-emerald-500" />
                  <span>No credit card required</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle className="w-4 h-4 text-emerald-500" />
                  <span>14-day free trial</span>
                </div>
              </div>
            </div>

            {/* Right Visual */}
            <div className="relative lg:pl-8">
              <div className="relative">
                {/* Main Image */}
                <div className="relative rounded-2xl overflow-hidden shadow-2xl bg-gray-100">
                  <ImageWithFallback
                    src="https://images.unsplash.com/photo-1522202176988-66273c2fd55f?w=800&h=600&fit=crop"
                    alt="AI-powered education platform dashboard"
                    className="w-full h-auto"
                  />
                </div>
                
                {/* Floating Stats Cards */}
                <div className="absolute -bottom-6 -left-6 bg-white rounded-xl shadow-lg border border-gray-100 p-4">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-emerald-100 rounded-lg flex items-center justify-center">
                      <TrendingUp className="w-5 h-5 text-emerald-600" />
                    </div>
                    <div>
                      <p className="font-semibold text-gray-900">50% Faster</p>
                      <p className="text-sm text-gray-500">Course Creation</p>
                    </div>
                  </div>
                </div>
                
                <div className="absolute -top-6 -right-6 bg-white rounded-xl shadow-lg border border-gray-100 p-4">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-teal-100 rounded-lg flex items-center justify-center">
                      <Users className="w-5 h-5 text-teal-600" />
                    </div>
                    <div>
                      <p className="font-semibold text-gray-900">10,000+</p>
                      <p className="text-sm text-gray-500">Students</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section - Light Background */}
      <section id="features" className="bg-white py-20">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-20">
            <div className="inline-flex items-center gap-2 bg-teal-50 border border-teal-200 rounded-full px-4 py-2 mb-6">
              <Rocket className="w-4 h-4 text-teal-600" />
              <span className="text-teal-700 font-medium text-sm">Core Features</span>
            </div>
            <h2 className="text-3xl lg:text-4xl xl:text-5xl font-black mb-6 text-gray-900">
              Everything you need to
              <br />
              <span className="bg-gradient-to-r from-teal-600 to-emerald-600 bg-clip-text text-transparent">
                scale your teaching
              </span>
            </h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              From curriculum generation to personalized feedback, our AI copilot handles the heavy lifting.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[
              {
                icon: BookOpen,
                title: "Curriculum Generation",
                description: "Generate complete lesson plans, slides, and exercises from simple prompts.",
                gradient: "from-emerald-500 to-teal-500"
              },
              {
                icon: Users,
                title: "Personalized Learning",
                description: "Tailor content to each student's background, interests, and learning style.",
                gradient: "from-teal-500 to-green-500"
              },
              {
                icon: Clock,
                title: "Content Freshness",
                description: "Stay current with automated updates from curated industry sources.",
                gradient: "from-green-500 to-emerald-500"
              },
              {
                icon: Target,
                title: "Human-in-the-Loop",
                description: "Maintain full editorial control with side-by-side diff reviews.",
                gradient: "from-emerald-600 to-teal-600"
              },
              {
                icon: Award,
                title: "Smart Assessment",
                description: "Auto-generate rubrics and provide personalized feedback.",
                gradient: "from-teal-600 to-green-600"
              },
              {
                icon: Zap,
                title: "Real-time Collaboration",
                description: "Work seamlessly with AI while maintaining your unique voice.",
                gradient: "from-green-600 to-emerald-600"
              }
            ].map((feature, index) => (
              <Card key={index} className="group bg-white border border-gray-200 hover:border-gray-300 transition-all duration-300 hover:shadow-lg">
                <CardHeader className="p-[21px]">
                  <div className={`w-12 h-12 bg-gradient-to-r ${feature.gradient} rounded-xl flex items-center justify-center mb-4`}>
                    <feature.icon className="w-6 h-6 text-white" />
                  </div>
                  <CardTitle className="text-lg font-semibold text-gray-900 mb-2">{feature.title}</CardTitle>
                  <CardDescription className="text-gray-600 leading-relaxed">
                    {feature.description}
                  </CardDescription>
                </CardHeader>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Stats Section - Dark Background */}
      <section className="bg-slate-900 text-white py-20">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-4 gap-8">
            {[
              { number: "50%", label: "Time Reduction", icon: Clock },
              { number: "10k+", label: "Students Reached", icon: Users },
              { number: "500+", label: "Educators", icon: Globe },
              { number: "95%", label: "Satisfaction Rate", icon: Star }
            ].map((stat, index) => (
              <div key={index} className="text-center group">
                <div className="w-16 h-16 bg-gradient-to-r from-emerald-500 to-teal-500 rounded-xl flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform duration-300">
                  <stat.icon className="w-8 h-8 text-white" />
                </div>
                <div className="text-3xl lg:text-4xl font-black text-white mb-2">{stat.number}</div>
                <div className="text-white/70 font-medium">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Benefits Section - Light Background */}
      <section id="benefits" className="bg-white py-20">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            <div>
              <div className="inline-flex items-center gap-2 bg-emerald-50 border border-emerald-200 rounded-full px-4 py-2 mb-6">
                <Award className="w-4 h-4 text-emerald-600" />
                <span className="text-emerald-700 font-medium text-sm">Proven Results</span>
              </div>
              
              <h2 className="text-3xl lg:text-4xl xl:text-5xl font-black mb-6 text-gray-900">
                Transform your
                <br />
                <span className="bg-gradient-to-r from-emerald-600 to-teal-600 bg-clip-text text-transparent">
                  teaching efficiency
                </span>
              </h2>
              
              <p className="text-lg text-gray-600 mb-8 leading-relaxed">
                Join hundreds of educators who have revolutionized their course creation process.
              </p>

              <div className="space-y-6">
                {[
                  {
                    title: "50% Faster Course Creation",
                    description: "Generate complete modules in hours, not weeks, while maintaining high standards.",
                    color: "emerald"
                  },
                  {
                    title: "Always Current Content",
                    description: "Automatically update your curriculum as new developments emerge.",
                    color: "teal"
                  },
                  {
                    title: "Personalized at Scale",
                    description: "Deliver tailored learning experiences to every student effortlessly.",
                    color: "green"
                  }
                ].map((benefit, index) => (
                  <div key={index} className="flex items-start gap-4">
                    <div className={`w-8 h-8 bg-gradient-to-r ${
                      benefit.color === 'emerald' ? 'from-emerald-500 to-teal-500' :
                      benefit.color === 'teal' ? 'from-teal-500 to-green-500' :
                      'from-green-500 to-emerald-500'
                    } rounded-lg flex items-center justify-center flex-shrink-0 mt-1`}>
                      <CheckCircle className="w-4 h-4 text-white" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-gray-900 mb-1">{benefit.title}</h3>
                      <p className="text-gray-600">{benefit.description}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="relative">
              <div className="relative rounded-2xl overflow-hidden shadow-xl bg-gray-100">
                <ImageWithFallback
                  src="https://images.unsplash.com/photo-1516321318423-f06f85e504b3?w=600&h=600&fit=crop"
                  alt="Diverse group of students learning"
                  className="w-full h-auto"
                />
              </div>
              
              <div className="absolute -top-4 -right-4 bg-white rounded-xl shadow-lg border border-gray-100 p-4">
                <div className="text-center">
                  <div className="text-2xl font-black text-gray-900 mb-1">85%</div>
                  <div className="text-sm text-gray-500">Time Savings</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Courses Section */}
      <section className="bg-gray-50 py-20">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <div className="inline-flex items-center gap-2 bg-blue-50 border border-blue-200 rounded-full px-4 py-2 mb-6">
              <BookOpen className="w-4 h-4 text-blue-600" />
              <span className="text-blue-700 font-medium text-sm">Featured Courses</span>
            </div>
            <h2 className="text-3xl lg:text-4xl xl:text-5xl font-black mb-6 text-gray-900">
              Master AI & Data Science
              <br />
              <span className="bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                with Expert-Led Courses
              </span>
            </h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto mb-8">
              Learn from industry professionals and academic experts with hands-on projects and real-world applications.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-12">
            {featuredCourses.map((course) => (
              <Card 
                key={course.id} 
                className="group overflow-hidden bg-white border border-gray-200 hover:border-gray-300 hover:shadow-xl transition-all duration-300 cursor-pointer"
                onClick={() => handleCourseClick(course.id)}
              >
                <div className="relative overflow-hidden">
                  <ImageWithFallback
                    src={course.image}
                    alt={course.title}
                    className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                  <div className="absolute top-4 left-4">
                    <Badge 
                      className={`${
                        course.difficulty === 'Beginner' ? 'bg-green-100 text-green-700' :
                        course.difficulty === 'Intermediate' ? 'bg-blue-100 text-blue-700' :
                        'bg-purple-100 text-purple-700'
                      } border-0`}
                    >
                      {course.difficulty}
                    </Badge>
                  </div>
                </div>
                
                <CardHeader className="pb-3">
                  <CardTitle className="text-xl font-semibold text-gray-900 mb-2">
                    {course.title}
                  </CardTitle>
                  <CardDescription className="text-gray-600 leading-relaxed">
                    {course.description}
                  </CardDescription>
                </CardHeader>
                
                <CardContent className="space-y-4">
                  <div className="flex items-center text-sm text-gray-500 space-x-4">
                    <div className="flex items-center gap-1">
                      <Clock className="w-4 h-4" />
                      <span>{course.duration}</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                      <span>{course.rating}</span>
                    </div>
                  </div>
                  
                  <div className="flex items-center justify-between pt-2">
                    <div>
                      <p className="text-sm text-gray-500">by {course.instructor}</p>
                    </div>
                    <Button 
                      size="sm"
                      className="bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-600 hover:to-teal-600"
                      onClick={(e) => {
                        e.stopPropagation();
                        setCurrentView("signup");
                      }}
                    >
                      Enroll Now
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          <div className="text-center">
            <Button 
              size="lg"
              variant="outline"
              className="text-lg px-8 py-3 h-auto border-2 border-gray-300 text-gray-700 hover:bg-gray-900 hover:text-white hover:border-gray-900"
              onClick={() => setCurrentView("courses")}
            >
              View All Courses
              <ChevronRight className="w-5 h-5 ml-2" />
            </Button>
          </div>
        </div>
      </section>

      {/* Testimonials - Dark Background */}
      <section className="bg-slate-900 text-white py-20">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <div className="inline-flex items-center gap-2 bg-emerald-500/10 border border-emerald-500/20 rounded-full px-4 py-2 mb-6">
              <Star className="w-4 h-4 text-emerald-400" />
              <span className="text-emerald-300 font-medium text-sm">Testimonials</span>
            </div>
            <h2 className="text-3xl lg:text-4xl xl:text-5xl font-black mb-4">
              <span className="bg-gradient-to-r from-white to-emerald-200 bg-clip-text text-transparent">
                Loved by educators
              </span>
              <br />
              <span className="bg-gradient-to-r from-emerald-400 to-teal-400 bg-clip-text text-transparent">
                worldwide
              </span>
            </h2>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                name: "Dr. Sarah Mitchell",
                role: "Professor, MIT",
                content: "This AI copilot has completely transformed how I create courses. What used to take weeks now takes days.",
                initials: "SM",
                gradient: "from-teal-500 to-green-500"
              },
              {
                name: "Prof. James Rodriguez",
                role: "Stanford University",
                content: "The personalization features are incredible. My students are more engaged than ever before.",
                initials: "JR",
                gradient: "from-emerald-500 to-teal-500"
              },
              {
                name: "Dr. Lisa Chen",
                role: "Carnegie Mellon",
                content: "Finally, an AI tool that understands pedagogy. It's like having an expert teaching assistant.",
                initials: "LC",
                gradient: "from-green-500 to-emerald-500"
              }
            ].map((testimonial, index) => (
              <Card key={index} className="bg-white/5 backdrop-blur-sm border border-white/10 hover:border-white/20 transition-all duration-300">
                <CardContent className="pt-6">
                  <div className="flex mb-4">
                    {[...Array(5)].map((_, i) => (
                      <Star key={i} className="w-4 h-4 fill-emerald-400 text-emerald-400" />
                    ))}
                  </div>
                  <p className="text-white/80 mb-6 leading-relaxed">
                    "{testimonial.content}"
                  </p>
                  <div className="flex items-center gap-3">
                    <div className={`w-10 h-10 bg-gradient-to-r ${testimonial.gradient} rounded-full flex items-center justify-center`}>
                      <span className="font-semibold text-white text-sm">{testimonial.initials}</span>
                    </div>
                    <div>
                      <p className="font-semibold text-white">{testimonial.name}</p>
                      <p className="text-white/60 text-sm">{testimonial.role}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section - Colored Background */}
      <section className="bg-gradient-to-r from-emerald-600 to-teal-600 text-white py-20">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h2 className="text-3xl lg:text-4xl xl:text-5xl font-black mb-6">
              Ready to revolutionize
              <br />
              your teaching?
            </h2>
            <p className="text-lg text-white/90 mb-8 max-w-2xl mx-auto">
              Join thousands of educators who are already using AI to create better courses faster.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button 
                size="lg" 
                className="bg-white text-emerald-600 hover:bg-gray-100 text-lg px-8 py-3 h-auto"
                onClick={() => setCurrentView("signup")}
              >
                Start Free Trial
                <ArrowRight className="w-5 h-5 ml-2" />
              </Button>
              <Button size="lg" variant="outline" className="border-white bg-white/10 text-white hover:bg-white/20 backdrop-blur-sm text-lg px-8 py-3 h-auto">
                Schedule Demo
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Footer - Dark Background */}
      <footer className="bg-slate-900 border-t border-white/10 py-16 text-white">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-4 gap-12">
            <div>
              <div className="flex items-center space-x-3 mb-6">
                <div className="w-8 h-8 bg-gradient-to-r from-emerald-500 to-teal-500 rounded-lg flex items-center justify-center">
                  <Brain className="w-5 h-5 text-white" />
                </div>
                <span className="text-xl font-semibold text-white">ProfessorAI</span>
              </div>
              <p className="text-white/60 leading-relaxed">
                Empowering educators with AI to create the most personalized learning experiences.
              </p>
            </div>
            
            {[
              {
                title: "Product",
                links: ["Features", "Pricing", "Documentation", "API"]
              },
              {
                title: "Company", 
                links: ["About", "Blog", "Careers", "Contact"]
              },
              {
                title: "Support",
                links: ["Help Center", "Community", "Privacy Policy", "Terms of Service"]
              }
            ].map((section, index) => (
              <div key={index}>
                <h4 className="font-semibold text-white mb-4">{section.title}</h4>
                <ul className="space-y-2">
                  {section.links.map((link, linkIndex) => (
                    <li key={linkIndex}>
                      <a href="#" className="text-white/60 hover:text-white transition-colors text-sm">{link}</a>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
          
          <div className="border-t border-white/10 mt-12 pt-8 text-center text-white/60 text-sm">
            <p>&copy; 2025 ProfessorAI. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}